// js/app.js
// -----------------------------------------------------------------------
// Application state + wiring. Talks to js/api.js for data and js/ui.js
// for rendering; holds no DOM logic of its own beyond attaching the
// top-level event listeners.
// -----------------------------------------------------------------------

import { fetchTasks, createTask, updateTaskStatus, deleteTask } from "./api.js";
import {
  renderLoading,
  renderError,
  renderEmpty,
  renderTasks,
  updateCount,
  setActiveTab,
  setComposerHint,
  setComposerBusy,
  clearComposerInput,
  getComposerValue,
} from "./ui.js";

const state = {
  status: "loading", // "loading" | "data" | "error"
  tasks: [],
  filter: "all", // "all" | "pending" | "completed"
  errorMessage: "",
};

async function loadTasks() {
  state.status = "loading";
  state.errorMessage = "";
  render();

  try {
    const tasks = await fetchTasks();
    state.tasks = tasks;
    state.status = "data";
  } catch (err) {
    state.status = "error";
    state.errorMessage =
      "We couldn't reach the task list. Check your connection and try again.";
    console.error(err);
  }
  render();
}

function getFilteredTasks() {
  if (state.filter === "pending") {
    return state.tasks.filter((t) => !t.completed);
  }
  if (state.filter === "completed") {
    return state.tasks.filter((t) => t.completed);
  }
  return state.tasks;
}

function render() {
  updateCount(state.tasks.length);
  setActiveTab(state.filter);

  if (state.status === "loading") {
    renderLoading();
    return;
  }

  if (state.status === "error") {
    renderError(state.errorMessage, loadTasks);
    return;
  }

  const filtered = getFilteredTasks();
  if (filtered.length === 0) {
    renderEmpty(state.filter);
    return;
  }

  renderTasks(filtered, {
    onToggle: handleToggle,
    onDelete: handleDelete,
  });
}

async function handleToggle(task) {
  const previous = task.completed;
  task.completed = !task.completed; // optimistic update
  render();

  try {
    await updateTaskStatus(task.id, task.completed);
  } catch (err) {
    task.completed = previous; // revert on failure
    render();
    flashComposerHint("Couldn't update that task. Please try again.");
    console.error(err);
  }
}

async function handleDelete(task) {
  const index = state.tasks.findIndex((t) => t.id === task.id);
  if (index === -1) return;

  const [removed] = state.tasks.splice(index, 1); // optimistic removal
  render();

  try {
    await deleteTask(task.id);
  } catch (err) {
    state.tasks.splice(index, 0, removed); // revert on failure
    render();
    flashComposerHint("Couldn't delete that task. Please try again.");
    console.error(err);
  }
}

async function handleComposerSubmit(event) {
  event.preventDefault();
  const title = getComposerValue();

  if (!title) {
    setComposerHint("Write something before adding it.");
    return;
  }

  setComposerHint("");
  setComposerBusy(true);

  try {
    const newTask = await createTask(title);
    state.tasks.unshift(newTask);
    clearComposerInput();
    render();
  } catch (err) {
    setComposerHint("Couldn't add that task. Please try again.");
    console.error(err);
  } finally {
    setComposerBusy(false);
  }
}

function flashComposerHint(message) {
  setComposerHint(message);
  setTimeout(() => setComposerHint(""), 3000);
}

function attachEvents() {
  document.getElementById("composer").addEventListener("submit", handleComposerSubmit);

  document.querySelectorAll(".tabs__item").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.filter = btn.dataset.filter;
      render();
    });
  });
}

attachEvents();
loadTasks();
