// js/ui.js
// -----------------------------------------------------------------------
// Pure(ish) rendering functions. Each one takes the container element(s)
// and the data it needs, and writes DOM. app.js decides *when* to call
// these; this file only decides *how* something looks.
// -----------------------------------------------------------------------

const entriesEl = document.getElementById("entries");
const tabsCountEl = document.getElementById("tabs-count");
const composerHintEl = document.getElementById("composer-hint");
const composerInputEl = document.getElementById("task-input");
const composerSubmitEl = document.getElementById("composer-submit");

/** Loading state: a few skeleton rows standing in for real entries. */
export function renderLoading() {
  entriesEl.innerHTML = `
    <div class="state state--loading" aria-label="Loading tasks">
      <div class="skeleton-row"></div>
      <div class="skeleton-row"></div>
      <div class="skeleton-row"></div>
    </div>
  `;
}

/** Error state: what went wrong, in plain language, with a retry action. */
export function renderError(message, onRetry) {
  entriesEl.innerHTML = `
    <div class="state state--error">
      <p class="state__title">The list didn't load</p>
      <p class="state__body">${escapeHtml(message)}</p>
      <button type="button" class="state__retry" id="retry-btn">Try again</button>
    </div>
  `;
  document.getElementById("retry-btn").addEventListener("click", onRetry);
}

/** Empty state: no tasks match the current filter. */
export function renderEmpty(filter) {
  const copy = {
    all: "No entries yet. Add your first task above.",
    pending: "Nothing pending — every task is checked off.",
    completed: "No completed tasks yet.",
  };
  entriesEl.innerHTML = `
    <div class="state state--empty">
      <p class="state__title">Nothing to show</p>
      <p class="state__body">${copy[filter] ?? copy.all}</p>
    </div>
  `;
}

/**
 * Data state: renders the task rows.
 * @param {Array} tasks
 * @param {{onToggle: Function, onDelete: Function}} handlers
 */
export function renderTasks(tasks, handlers) {
  entriesEl.innerHTML = tasks.map((task) => taskRowHtml(task)).join("");

  tasks.forEach((task) => {
    const row = entriesEl.querySelector(`[data-id="${task.id}"]`);
    if (!row) return;
    row.querySelector(".entry__toggle").addEventListener("click", () => {
      handlers.onToggle(task);
    });
    row.querySelector(".entry__delete").addEventListener("click", () => {
      handlers.onDelete(task);
    });
  });
}

function taskRowHtml(task) {
  const status = task.completed ? "completed" : "pending";
  const label = task.completed ? "Completed" : "Pending";
  const marking = task._pending ? "is-pending-request" : "";
  return `
    <div class="entry ${marking}" data-status="${status}" data-id="${task.id}">
      <button
        type="button"
        class="entry__toggle"
        aria-pressed="${task.completed}"
        aria-label="${task.completed ? "Mark as pending" : "Mark as completed"}"
      ></button>
      <div class="entry__body">
        <p class="entry__title">${escapeHtml(task.title)}</p>
        <span class="entry__meta">${label}</span>
      </div>
      <button type="button" class="entry__delete" aria-label="Delete task">×</button>
    </div>
  `;
}

/** Updates the small "N tasks" counter next to the filter tabs. */
export function updateCount(count) {
  tabsCountEl.textContent = count === 1 ? "1 task" : `${count} tasks`;
}

/** Marks which filter tab is currently active. */
export function setActiveTab(filter) {
  document.querySelectorAll(".tabs__item").forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.filter === filter);
  });
}

/** Shows/clears a validation or submission message under the composer. */
export function setComposerHint(message) {
  composerHintEl.textContent = message ?? "";
}

/** Disables the composer while a create request is in flight. */
export function setComposerBusy(isBusy) {
  composerSubmitEl.disabled = isBusy;
  composerSubmitEl.textContent = isBusy ? "Adding…" : "Add";
}

export function clearComposerInput() {
  composerInputEl.value = "";
  composerInputEl.focus();
}

export function getComposerValue() {
  return composerInputEl.value.trim();
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
