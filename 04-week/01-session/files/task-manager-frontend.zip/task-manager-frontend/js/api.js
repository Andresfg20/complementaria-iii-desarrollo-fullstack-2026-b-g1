// js/api.js
// -----------------------------------------------------------------------
// All network access lives here. Nothing else in the app should call
// fetch() directly — this keeps the API contract in one place and makes
// it easy to swap the demo API for a real backend later.
//
// Demo API: DummyJSON Todos (https://dummyjson.com/docs/todos)
// Note: DummyJSON is a mock API. POST/PUT/DELETE are accepted and echoed
// back with a realistic response, but nothing is persisted server-side,
// so a page refresh will reset the list to the seeded data.
// -----------------------------------------------------------------------

const BASE_URL = "https://dummyjson.com/todos";
const LIST_LIMIT = 20;

async function parseOrThrow(response) {
  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }
  return response.json();
}

/** GET /todos — returns the seeded task list. */
export async function fetchTasks() {
  const response = await fetch(`${BASE_URL}?limit=${LIST_LIMIT}`);
  const data = await parseOrThrow(response);
  return data.todos.map(mapTodoToTask);
}

/** POST /todos/add — creates a new task. */
export async function createTask(title) {
  const response = await fetch(`${BASE_URL}/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      todo: title,
      completed: false,
      userId: 1,
    }),
  });
  const data = await parseOrThrow(response);
  return mapTodoToTask(data);
}

/** PUT /todos/:id — toggles a task's completed state. */
export async function updateTaskStatus(id, completed) {
  const response = await fetch(`${BASE_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ completed }),
  });
  const data = await parseOrThrow(response);
  return mapTodoToTask(data);
}

/** DELETE /todos/:id — removes a task. */
export async function deleteTask(id) {
  const response = await fetch(`${BASE_URL}/${id}`, { method: "DELETE" });
  return parseOrThrow(response);
}

/** Normalizes the API's `todo` shape into this app's `task` shape. */
function mapTodoToTask(todo) {
  return {
    id: todo.id,
    title: todo.todo,
    completed: Boolean(todo.completed),
  };
}
